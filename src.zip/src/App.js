// App.js
import React from 'react';
import PaginaPrincipal from './Components/Pages/PaginaPrincipal.js';

const App = () => {
  return (
    <div>
      <PaginaPrincipal />
    </div>
  );
};

export default App;
